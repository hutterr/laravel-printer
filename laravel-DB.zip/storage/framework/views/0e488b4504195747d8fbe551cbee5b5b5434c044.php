<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Felhasznált alkatrészek', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
    <?php echo e($errors->first('uzenet')); ?>

    </div>
  <?php endif; ?>
<table class="table table-hover mx-auto mt-3" >
        <thead>
          <tr>
            <th class="text-center" scope="col">Dátum</th>
            <th class="text-center" scope="col">DB</th>
            <th class="text-center" scope="col">EDP</th>
            <th class="text-center"scope="col">Megnevezés</th>
            <th class="text-center" scope="col">Egységár</th> 
            <th class="text-center" scope="col">Összes ár</th>
            
            
          
          </tr>
        </thead>
        <tbody>
          <?php if(count($felhasznalas) == 0): ?>
          <tr>
                  <th scope="row" colspan="7" class="text-center">Nem volt alkatrész felhasználás!</th>             
          </tr>
          <?php else: ?>
              <?php $__currentLoopData = $felhasznalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $felhasznalt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
              <tr>             
                <td class="align-middle text-center"><?php echo e($felhasznalt->created_at->format('Y/m/d')); ?></td>
                <td class="align-middle text-center"><?php echo e($felhasznalt->db); ?></td>
                <td class="align-middle text-center"><?php echo e($felhasznalt->alkatresz->edp); ?></td>
                <td class="align-middle text-center"><?php echo e($felhasznalt->alkatresz->megnevezes); ?></td>
                <td class="align-middle text-center"><?php echo e(number_format($felhasznalt->ar,0, ' ', ' ')); ?> Ft</td>
                <td class="align-middle text-center"><?php echo e(number_format($felhasznalt->db * $felhasznalt->ar, 0, ' ', ' ')); ?> Ft</td>  
                          
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table> 
      <?php if(count($felhasznalas) > 0): ?>
            <div class="paginate mx-auto mt-2" >
                <?php echo e($felhasznalas->links()); ?>            
            </div>
        <?php endif; ?>    
     
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/parts/usedShow.blade.php ENDPATH**/ ?>