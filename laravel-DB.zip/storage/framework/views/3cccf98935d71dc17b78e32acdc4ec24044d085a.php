<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Alkatrész felvétele'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">             

            </div>

        </div>
        <div class="card-body">
            <form class="col-lg-11 mx-auto" action="/alkatresz" method="POST">         
                <div class="form-group row">
                        <label for="edp" class="col-sm-2 col-form-label ">EDP kód</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="edp" name="edp" value="<?php echo e(old('edp')); ?>">
                            <small><?php echo e($errors->first('edp')); ?></small>
                        </div>
                        </div>
                          <div class="form-group row">
                        <label for="megnevezes" class="col-sm-2 col-form-label">Megnevezés</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="megnevezes" name="megnevezes" value="<?php echo e(old('megnevezes')); ?>" >
                            <small><?php echo e($errors->first('megnevezes')); ?></small>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label for="ar" class="col-sm-2 col-form-label ">Beszer. ár</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="ar" name="ar" value="<?php echo e(old('ar')); ?>">
                                <small><?php echo e($errors->first('ar')); ?></small>
                            </div>
                        </div>
                        <div class="row justify-content-center my-3">
                                <button type="submit" class="btn btn-primary col-lg-2">Rögzités</button>                    
                        </div>     

                <?php echo csrf_field(); ?>
            </form>  
            
      </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/parts/create.blade.php ENDPATH**/ ?>