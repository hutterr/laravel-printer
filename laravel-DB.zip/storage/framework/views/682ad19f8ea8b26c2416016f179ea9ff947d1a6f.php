<div class="form-group row">
        <label for="cegnev" class="col-sm-2 col-form-label text-right">Cégnév</label>
        <div class="col-sm-10">
          <input type="text" class="form-control<?php echo e(($errors->first('cegnev') ? " fail" : "")); ?>" id="cegnev" name="cegnev" value="<?php echo e(old('cegnev') ?? $ceg->cegnev); ?>">
          <small><?php echo e($errors->first('cegnev')); ?></small>
        </div>
      </div>
      <div class="form-group row">
              <label for="adoszam" class="col-sm-2 col-form-label text-right">Adószám</label>
              <div class="col-sm-10">
                <input type="text" class="form-control<?php echo e(($errors->first('adoszam') ? " fail" : "")); ?>" id="adoszam" name="adoszam" value="<?php echo e(old('adoszam') ?? $ceg->adoszam); ?>">
                <small><?php echo e($errors->first('adoszam')); ?></small>
              </div>
      </div>
      <div class="form-group row">
              <label for="cim" class="col-sm-2 col-form-label text-right">Cím</label>
              <div class="col-sm-10">
                <input type="text" class="form-control <?php echo e(($errors->first('cim') ? " fail" : "")); ?>" id="cim" name="cim" value="<?php echo e(old('cim') ?? $ceg->cim); ?>">
                <small><?php echo e($errors->first('cim')); ?></small>
              </div>
      </div>
      <div class="form-group row">
              <label for="telefon" class="col-sm-2 col-form-label text-right">Telefonszám:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control<?php echo e(($errors->first('telefon') ? " fail" : "")); ?>" id="telefon" name="telefon" value="<?php echo e(old('telefon') ?? $ceg->telefon); ?>">
                <small><?php echo e($errors->first('telefon')); ?></small>
              </div>
      </div>
      <div class="form-group row">
              <label for="kapcsolattarto" class="col-sm-2 col-form-label text-right">Kapcsolattartó neve</label>
              <div class="col-sm-10">
                <input type="text" class="form-control<?php echo e(($errors->first('kapcsolattarto') ? " fail" : "")); ?>" id="kapcsolattarto" name="kapcsolattarto" value="<?php echo e(old('kapcsolattarto') ?? $ceg->kapcsolattarto); ?>">
                <small><?php echo e($errors->first('kapcsolattarto')); ?></small>
              </div>
      </div>
      <div class="form-group row">
              <label for="kapcstel" class="col-sm-2 col-form-label text-right">Kapcs. telefonszám</label>
              <div class="col-sm-10">
                <input type="text" class="form-control<?php echo e(($errors->first('kapcstel') ? " fail" : "")); ?>" id="kapcstel" name="kapcstel" value="<?php echo e(old('kapcstel') ?? $ceg->kapcstel); ?>">
                <small><?php echo e($errors->first('kapcstel')); ?></small>
              </div>
      </div>
      <div class="row justify-content-center">
          <button type="submit" class="btn btn-primary col-lg-2"><?php echo e($felirat); ?></button>                    
      </div><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/cegek/form.blade.php ENDPATH**/ ?>