<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
        <?php if($errors->any()): ?>
        <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
        <?php echo e($errors->first('uzenet')); ?>

        </div>
      <?php endif; ?>
</div>
     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/repair/index.blade.php ENDPATH**/ ?>