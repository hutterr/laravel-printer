<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
        <?php if($errors->any()): ?>
        <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
        <?php echo e($errors->first('uzenet')); ?>

        </div>
      <?php endif; ?>
</div>
<div class="row mx-auto" style="width: 80%">
  <form class="col-lg-2 form-inline" action="<?php echo e(route('alkatresz.index')); ?>" method="get">
      <div class="form-group">
          <input class="form-control" name="edp" placeholder="EDP kód">
        <div class="col-lg-2">
          <input class="btn btn-primary" type="submit" value="Keresés">
        </div>
      </div>
    </form>
    <form class="col-lg-2 form-inline ml-auto" action="<?php echo e(route('alkatresz.index')); ?>" method="get">
      <div class="form-group">
          <input class="form-control" name="megnevezes" placeholder="Megnevezés">
        <div class="col-lg-2">
          <input class="btn btn-primary" type="submit" value="Keresés">
        </div>
      </div>
    </form>
<table class="table table-hover mx-auto mt-3" >
        <thead>
          <tr>
            <th class="text-center" scope="col">EDP kód</th>
            <th class="text-center" scope="col">Megnevezés</th>
            <th class="text-center" scope="col">Ár</th>           
            <th class="text-center" scope="col"></th>
            
          
          </tr>
        </thead>
        <tbody>
          <?php if(count($alkatreszek) == 0): ?>
          <tr>
                  <th scope="row" colspan="7" class="text-center">Nincsen alkatrész!</th>             
          </tr>
          <?php else: ?>
              <?php $__currentLoopData = $alkatreszek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alkatresz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
              <tr>             
              <td class="align-middle text-center"><?php echo e($alkatresz->edp); ?></td>
              <td class="align-middle text-center"><?php echo e($alkatresz->megnevezes); ?></td>
              <td class="align-middle text-center"><?php echo e($alkatresz->ar); ?></td>
              <td class="align-middle text-center"><a class="btn btn-primary" href="/alkatresz/<?php echo e($alkatresz->id); ?>/edit">Módosítás</a></td>
                 
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table> 
      <?php if(count($alkatreszek) > 0): ?>
              <div class="paginate mx-auto mt-2" >
                  <?php echo e($alkatreszek->links()); ?>            
              </div>
      <?php endif; ?>
     
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/parts/show.blade.php ENDPATH**/ ?>