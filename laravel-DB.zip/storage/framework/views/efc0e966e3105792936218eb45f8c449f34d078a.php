<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Számláló rögzítése'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">             

            </div>

        </div>
        <div class="card-body">
            <form class="col-lg-11 mx-auto" action="/javitasok" method="POST">         
                <div class="form-group row">
                        <label for="printer_id" class="col-sm-2 col-form-label ">Gépszám</label>
                        <div class="col-sm-10">
                                <select class="form-control" id="printerSelect" name="printer_id">
                                    <?php if($nyomtatok->count() == 0): ?>{
                                        <option disabled>Még nincsenek nyomtatok...</option>
                                    }
                                    <?php else: ?>
                                        <?php $__currentLoopData = $nyomtatok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nyomtato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($nyomtato->id); ?>" ><?php echo e($nyomtato->gepszam); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                  
                                </select>
                        </div>
                </div>
                <div class="form-group row">
                        <label for="datum" class="col-sm-2 col-form-label ">Dátum</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="datum" name="datum" value="<?php echo e(old('datum')); ?>">
                            <small><?php echo e($errors->first('datum')); ?></small>
                        </div>
                        </div>
                          <div class="form-group row">
                        <label for="fekete" class="col-sm-2 col-form-label">Fekete számláló</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="fekete" name="fekete" value="<?php echo e(old('fekete')); ?>" >
                            <small><?php echo e($errors->first('fekete')); ?></small>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label for="szines" class="col-sm-2 col-form-label ">Szines</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="szines" name="szines" value="<?php echo e(old('szines')); ?>">
                                <small><?php echo e($errors->first('szines')); ?></small>
                            </div>
                        </div>
                        <div class="form-group row">
                                <label for="megjegyzes" class="col-sm-2 col-form-label ">Megjegyzés</label>
                                <div class="col-sm-10">
                                    <textarea type="text" class="form-control" rows="5" id="megjegyzes" name="megjegyzes" ><?php echo e(old('megjegyzes')); ?></textarea>
                                    <small><?php echo e($errors->first('megjegyzes')); ?></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                    <label for="technikus" class="col-sm-2 col-form-label ">Technikus</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="technikus" name="technikus" value="<?php echo e(Auth::user()->name); ?>" readonly>
                                        <small><?php echo e($errors->first('technikus')); ?></small>
                                    </div>
                                </div>
                        <div class="row justify-content-center my-3">
                                <button type="submit" class="btn btn-primary col-lg-2">Rögzités</button>                    
                        </div>     

                <?php echo csrf_field(); ?>
            </form>  
            
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
      <script type="text/javascript">
             $(document).ready(function(){
                $('#printerSelect').select2();
             });
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/repair/create.blade.php ENDPATH**/ ?>