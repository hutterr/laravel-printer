<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Cégek listája', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
    <?php echo e($errors->first('uzenet')); ?>

    </div>
  <?php endif; ?>
  <div class="row mx-auto mt-3" style="width: 80%">
    <form class="col-lg-2 form-inline" action="<?php echo e(route('cegek.index')); ?>" method="get">
        <div class="form-group">
            <input class="form-control" name="cegnev" placeholder="Cégnév">
          <div class="col-lg-2">
            <input class="btn btn-primary" type="submit" value="Keresés">
          </div>
        </div>
      </form>
  </div>
<table class="table table-hover mx-auto mt-3" >
        <thead>
          <tr>
            <th class="text-center" scope="col">Cégnév</th>
            <th class="text-center" scope="col">Adószám</th>
            <th class="text-center" scope="col">Cím</th>
            <th class="text-center"scope="col">Telefon</th>
            <th class="text-center" scope="col">Kapcsolattartó</th>
            <th class="text-center" scope="col">Kapcs. telefon</th>
          
          </tr>
        </thead>
        <tbody>
          <?php if(count($cegek) == 0): ?>
          <tr>
                  <th scope="row" colspan="7" class="text-center">Nincsenek még cégek!</th>             
          </tr>
          <?php else: ?>
              <?php $__currentLoopData = $cegek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ceg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
              <tr>
             
              <td class="align-middle text-center"><a class="button-list" href="\cegek\<?php echo e($ceg->id); ?>"><?php echo e($ceg->cegnev); ?></a></td>
              <td class="align-middle text-center"><?php echo e($ceg->adoszam); ?></td>
              <td class="align-middle text-center"><?php echo e($ceg->cim); ?></td>
              <td class="align-middle text-center"><?php echo e($ceg->telefon); ?></td>
              <td class="align-middle text-center"><?php echo e($ceg->kapcsolattarto); ?></td>
              <td class="align-middle text-center"><?php echo e($ceg->kapcstel); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table> 
      <?php if(count($cegek) > 0): ?>
              <div class="paginate mx-auto mt-2" >
                  <?php echo e($cegek->links()); ?>            
              </div>
      <?php endif; ?>
     
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/cegek/index.blade.php ENDPATH**/ ?>