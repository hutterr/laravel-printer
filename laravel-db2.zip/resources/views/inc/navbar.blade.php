<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand mx-auto" disabled><h2><strong>{{$title}}</h2></strong></a>
</nav>