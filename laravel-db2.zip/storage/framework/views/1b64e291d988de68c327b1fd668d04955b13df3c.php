<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Részletek', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-12 mx-auto mt-3">
    <div class="row">
            <div class="col-lg-5 mb-2">
                    <div class="card">
                            <div class="card-header">
                                <h5 class="text-center">Fekete számláló</h5>
                                <h5 class="text-center">Havi átlag <?php echo e($atlagFekete); ?> oldal</h5>
                            </div>
                            <div class="card-body">
                                <div>
                                    <?php echo $feketeChart->container(); ?>

                                </div>
                        </div>
                        </div>
            </div>
            <div class="col-lg-5">
                    <div class="card">
                            <div class="card-header">
                                    <h5 class="text-center">Színes számláló</h5>
                                    <h5 class="text-center">Havi átlag <?php echo e($atlagSzines); ?> oldal</h5>
                            </div>
                            <div class="card-body">
                                <div>
                                    <?php echo $szinesChart->container(); ?>

                                </div>
                        </div>
                        </div>
            </div>
            <div class="col-lg-2">
                <div class="card">
                        <div class="card-header">
                                <h5 class="text-center">Költségek</h5>
                                
                        </div>
                        <div class="card-body">
                            <div class="border p-2">
                                <div class="text-center">
                                    Elhasznált alkatrész ktg:<br> <?php echo e(number_format($alkKoltsegSzum, 0, ' ', ' ')); ?> Ft.
                                </div>
                                <div class="row justify-content-center">
                                    <a class="btn btn-primary" href="\hasznalt\<?php echo e($printer->id); ?>">Részletek</a>
    
                                </div>

                            </div>
                            <div class="text-center mt-2 border p-2">
                                Beszerzési ár: <br> <?php echo e(number_format($printer->beszer_ar, 0, ' ', ' ')); ?> Ft.
                            </div>
                            
                    </div>
                    </div>
        </div>
        </div>
        <div class="row">
            <div class="col-lg-4 mb-2">
                    <div class="card" style="min-height: 450px">
                    <div class="card-header">
                            <h5 class="text-center">Adatok</h5>
                    </div>
                    <div class="card-body">
                            <div class="form-group row">
                                    <label for="gepszam" class="col-sm-4 col-form-label ">Gépszám</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="gepszam" name="gepszam" value="<?php echo e($printer->gepszam); ?>" <?php if(isset($printer->gepszam)): ?> readonly <?php endif; ?>>
                                        <small><?php echo e($errors->first('gepszam')); ?></small>
                                    </div>
                                    </div>
                                      <div class="form-group row">
                                    <label for="gyszam" class="col-sm-4 col-form-label ">Gyári szám</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="gyszam" name="gyszam" value="<?php echo e($printer->gyszam); ?>" <?php if(isset($printer->gyszam)): ?> readonly <?php endif; ?>>
                                        <small><?php echo e($errors->first('gyszam')); ?></small>
                                    </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="marka" class="col-sm-4 col-form-label ">Márka</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="marka" name="marka" value="<?php echo e($printer->marka); ?>" readonly>
                                            <small><?php echo e($errors->first('marka')); ?></small>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                            <label for="geptipus" class="col-sm-4 col-form-label ">Géptípus</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="geptipus" name="geptipus" value="<?php echo e($printer->geptipus); ?>" readonly>
                                                <small><?php echo e($errors->first('geptipus')); ?></small>
                                            </div>
                                    </div>
                                    <div class="form-group row">
                                            <label for="ceg" class="col-sm-4 col-form-label ">Cég</label>
                                            <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="geptipus" name="geptipus" value="<?php echo e($printer->ceg()->first()->cegnev); ?>" readonly>
                                            </div>
                                    </div>
                                    <div class="form-group row">
                                            <label for="ceg" class="col-sm-4 col-form-label ">Kapcsolattartó</label>
                                            <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="kapcsolattarto" name="kapcsolattarto" value="<?php echo e($printer->ceg()->first()->kapcsolattarto); ?>" readonly>
                                            </div>
                                    </div>
                                    <div class="form-group row">
                                            <label for="ceg" class="col-sm-4 col-form-label ">Kapcs. telefon</label>
                                            <div class="col-sm-8">
                                                    <input type="text" class="form-control" id="kapcstel" name="kapcstel" value="<?php echo e($printer->ceg()->first()->kapcstel); ?>" readonly>
                                            </div>
                                    </div>
                                    <div class="form-group row">
                                            <label for="hely" class="col-sm-4 col-form-label ">Jelengi hely</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="hely" name="hely" value="<?php echo e($printer->hely); ?>" readonly>
                                                <small><?php echo e($errors->first('hely')); ?></small>
                                            </div>
                                    </div>

                                    <div class="form-group row">
                                            <label for="telefon" class="col-sm-4 col-form-label ">Hely telefon</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" id="telefon" name="telefon" value="<?php echo e($printer->telefon); ?>" readonly>
                                                <small><?php echo e($errors->first('telefon')); ?></small>
                                            </div>
                                    </div>
                                    <div class="row justify-content-center">
                                        <a class="btn btn-primary" href="\nyomtatok\<?php echo e($printer->id); ?>\edit">Részletek</a>

                                    </div>
                </div>
            </div>
            </div>
            <div class="col-lg-3 mb-2">
                <div class="card" style="min-height: 450px">
                <div class="card-header">
                        <h5 class="text-center">Számláló táblázat</h5>
                </div>
                <div class="card-body">
                <table class="table table-hover mx-auto mt-3" >
                        <thead>
                            <tr>
                            <th class="text-center" scope="col">Dátum</th>
                            <th class="text-center" scope="col">Fekete</th>
                            <th class="text-center" scope="col">Színes</th>
                            
                            
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($szamlalok) == 0): ?>
                            <tr>
                                    <th scope="row" colspan="3" class="text-center">Nincsenek számlálók!</th>             
                            </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $szamlalok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $szamlalo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                <tr>             
                                <td class="align-middle text-center"><?php echo e(date("Y-m-d", strtotime($szamlalo->bejelentesi_datum))); ?></td>
                                <td class="align-middle text-center"><?php echo e($szamlalo->fekete); ?></td>
                                <td class="align-middle text-center"><?php echo e($szamlalo->szines); ?></td>
                                
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                        </table> 
                        <?php if(count($szamlalok) > 0): ?>
                        <div class="paginate mx-auto mt-2" >
                            <?php echo e($szamlalok->links()); ?>            
                        </div>
                    <?php endif; ?>    
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card" style="min-height: 450px">
                    <div class="card-header">
                            <h5 class="text-center">Javítások táblázat</h5>
                    </div>
                    <div class="card-body">
                            <table class="table table-hover mx-auto mt-3" >
                                    <thead>
                                        <tr>
                                        <th class="text-center" scope="col">Dátum</th>
                                        <th class="text-center" scope="col">Fekete</th>
                                        <th class="text-center" scope="col">Színes</th>
                                        <th class="text-center" scope="col">Technikus</th>
                                        <th class="text-center" scope="col"></th>
                                        
                                        
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($javitasok) == 0): ?>
                                        <tr>
                                                <th scope="row" colspan="5" class="text-center">Nincsenek javítások!</th>             
                                        </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $javitasok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $javitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
                                            <tr>             
                                                <td class="align-middle text-center"><?php echo e($javitas->created_at->format('Y/m/d')); ?></td>
                                                <td class="align-middle text-center"><?php echo e($javitas->fekete); ?></td>
                                                <td class="align-middle text-center"><?php echo e($javitas->szines); ?></td>
                                                <td class="align-middle text-center"><?php echo e($javitas->technikus); ?></td>      
                                                <td class="align-middle text-center"><a href="/javitasok/<?php echo e($javitas->id); ?>">Részletek</a></td>                                           
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                    </table> 
                                    <?php if(count($javitasok) > 0): ?>
                                    <div class="paginate mx-auto mt-2" >
                                        <?php echo e($javitasok->links()); ?>            
                                    </div>
                                <?php endif; ?>    
                    </div>
                </div>
        </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>

<?php echo $feketeChart->script(); ?>

<?php echo $szinesChart->script(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/printer/details.blade.php ENDPATH**/ ?>