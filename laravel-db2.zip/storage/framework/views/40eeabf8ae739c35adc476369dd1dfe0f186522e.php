<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Részletek', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">
                <h5 class="text-left col-lg-6"><?php echo e($ceg->id); ?> - <?php echo e($ceg->cegnev); ?></h5>
                <h5 class="text-right col-lg-6">Létrehozva: <?php echo e($ceg->created_at->format('Y.m.d')); ?> </h5>

            </div>

        </div>
        <div class="card-body">
            <form class="col-lg-11" action="/cegek/<?php echo e($ceg->id); ?>" method="POST">
                <?php echo method_field('patch'); ?>
                <?php echo $__env->make('cegek.form', ['felirat' => 'Módosítás'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo csrf_field(); ?>
            </form>  
            <div class="row justify-content-end mr-4">
                <button type="button" class="btn btn-danger col-lg-2" data-toggle="modal" data-target="#megerosites" >
                    Törlés
                </button>
            </div>       
        </div>
      </div>
      <div  id="megerosites" class="modal" role="dialog">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title">Biztos benne?</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <form class="col-lg-12" action="/cegek/<?php echo e($ceg->id); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger btn-block" >Igen</button>                           
                                <?php echo csrf_field(); ?>
                            </form>    
                        </div>
                        <div class="col-lg-6">
                            <button type="button" data-dismiss="modal" class="btn btn-primary btn-block">Mégse</button>
                        </div>                   
                    </div>
                </div>
              </div>
            </div>
          </div>
</div>
<?php 
    $nyomtatok = $ceg->printer()->paginate(10);

?>
<h1 class="text-center my-3 mx-auto py-2 bg-secondary col-lg-11 text-white">A cég nyomtatói</h1>
<table class="table table-hover mx-auto mt-3" >
    <thead>
      <tr>
        <th class="text-center" scope="col">Gépszam</th>
        <th class="text-center" scope="col">Márka</th>
        <th class="text-center" scope="col">Típus</th>
       
        <th class="text-center" scope="col"></th>
        
      
      </tr>
    </thead>
    <tbody>
      <?php if(count($nyomtatok) == 0): ?>
      <tr>
              <th scope="row" colspan="7" class="text-center">Nincsenek még nyomtatók!</th>             
      </tr>
      <?php else: ?>
          <?php $__currentLoopData = $nyomtatok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nyomtato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
          <tr>             
            <td class="align-middle text-center"><a class="button-list" href="\nyomtatok\<?php echo e($nyomtato->id); ?>\edit"><?php echo e($nyomtato->gepszam); ?></a></td>
            <td class="align-middle text-center"><?php echo e($nyomtato->marka); ?></td>
            <td class="align-middle text-center"><?php echo e($nyomtato->geptipus); ?></td>
            <td class="align-middle text-center"><a class="button-list" href="\nyomtatok\<?php echo e($nyomtato->id); ?>">Részletek</a></td>            
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </tbody>
  </table> 
  <?php if(count($nyomtatok) > 0): ?>
          <div class="paginate mx-auto mt-2" >
              <?php echo e($nyomtatok->links()); ?>            
          </div>
  <?php endif; ?>
<script>
  
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/cegek/details.blade.php ENDPATH**/ ?>