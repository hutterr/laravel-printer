<?php $__env->startSection('content'); ?>

   
        <div class="col-md-11 mt-4 mx-auto">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h1 class="text-center">Sikeres bejelentkezés!</h1>
                </div>
            </div>
        </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/home.blade.php ENDPATH**/ ?>