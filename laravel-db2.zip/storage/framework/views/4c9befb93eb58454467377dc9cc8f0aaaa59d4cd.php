<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Létrehozás', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">             

            </div>

        </div>
        <div class="card-body">
            <form class="col-lg-11 mx-auto" action="/nyomtatok" method="POST">         
                <?php echo $__env->make('printer.form', ['felirat' => 'Hozzáadás'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
              
                    
                <?php echo csrf_field(); ?>
            </form>  
            
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
      <script type="text/javascript">
             $(document).ready(function(){
                $('#ceg').select2();
                
             });
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/printer/create.blade.php ENDPATH**/ ?>