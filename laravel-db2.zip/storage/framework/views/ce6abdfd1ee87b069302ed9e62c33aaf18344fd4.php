<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/welcome.blade.php ENDPATH**/ ?>