<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand mx-auto" disabled><h2><strong><?php echo e($title); ?></h2></strong></a>
</nav><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/inc/navbar.blade.php ENDPATH**/ ?>