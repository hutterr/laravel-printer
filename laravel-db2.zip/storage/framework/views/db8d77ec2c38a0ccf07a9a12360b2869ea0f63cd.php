<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Javítás részletek'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
        <?php if($errors->any()): ?>
        <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
        <?php echo e($errors->first('uzenet')); ?>

        </div>
      <?php endif; ?>
</div>
 <div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">             

            </div>

        </div>
        <div class="card-body">
            <div class="form-group row">
                <label for="datum" class="col-sm-2 col-form-label ">Gép adatok</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="datum" name="datum" value="<?php echo e($javitas->nyomtato()->first()->gepszam); ?> - <?php echo e($javitas->nyomtato()->first()->marka); ?> <?php echo e($javitas->nyomtato()->first()->geptipus); ?>">
                    <small><?php echo e($errors->first('datum')); ?></small>
                </div>
                </div>           
            
                <div class="form-group row">
                        <label for="datum" class="col-sm-2 col-form-label ">Dátum</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="datum" name="datum" value="<?php echo e($javitas->datum); ?>">
                            <small><?php echo e($errors->first('datum')); ?></small>
                        </div>
                        </div>
                          <div class="form-group row">
                        <label for="fekete" class="col-sm-2 col-form-label">Fekete számláló</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="fekete" name="fekete" value="<?php echo e($javitas->fekete); ?>" >
                            <small><?php echo e($errors->first('fekete')); ?></small>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label for="szines" class="col-sm-2 col-form-label ">Szines</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="szines" name="szines" value="<?php echo e($javitas->szines); ?>">
                                <small><?php echo e($errors->first('szines')); ?></small>
                            </div>
                        </div>
                        <div class="form-group row">
                                <label for="megjegyzes" class="col-sm-2 col-form-label ">Megjegyzés</label>
                                <div class="col-sm-10">
                                    <textarea type="text" class="form-control" rows="5" id="megjegyzes" name="megjegyzes" ><?php echo e($javitas->megjegyzes); ?></textarea>
                                    <small><?php echo e($errors->first('megjegyzes')); ?></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                    <label for="technikus" class="col-sm-2 col-form-label ">Technikus</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="technikus" name="technikus" value="<?php echo e($javitas->technikus); ?>" readonly>
                                        <small><?php echo e($errors->first('technikus')); ?></small>
                                    </div>
                                </div>
                            

            
      </div>
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/repair/show.blade.php ENDPATH**/ ?>