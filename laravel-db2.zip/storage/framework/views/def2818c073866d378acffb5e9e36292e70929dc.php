<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Alkatrész elhasználás'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-11 mx-auto mt-3">
    <div class="card">
        <div class="card-header">
            <div class="row">             

            </div>

        </div>
        <div class="card-body">
            <form class="col-lg-11 mx-auto" action="/hasznalt" method="POST"> 
                <div class="form-group row">
                        <label for="printer_id" class="col-sm-2 col-form-label ">Gépszám</label>
                        <div class="col-sm-10">
                                <select class="form-control" id="printerSelect" name="printer_id">
                                    <?php if($nyomtatok->count() == 0): ?>{
                                        <option disabled>Még nincsenek nyomtatok...</option>
                                    }
                                    <?php else: ?>
                                        <?php $__currentLoopData = $nyomtatok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nyomtato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($nyomtato->id); ?>" ><?php echo e($nyomtato->gepszam); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                  
                                </select>
                        </div>
                </div> 
                <div class="form-group row">
                        <label for="db" class="col-sm-2 col-form-label ">Darabszám</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="db" name="db" value="<?php echo e(old('db')); ?>">
                            <small><?php echo e($errors->first('db')); ?></small>
                        </div>
                        </div>
                <div class="form-group row">
                        <label for="parts_id" class="col-sm-2 col-form-label ">Alkatrész</label>
                        <div class="col-sm-10">
                                <select class="form-control" id="partsSelect" name="parts_id">
                                    <?php if($alkatreszek->count() == 0): ?>{
                                        <option disabled>Még nincsenek alkatrészek...</option>
                                    }
                                    <?php else: ?>
                                        <?php $__currentLoopData = $alkatreszek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alkatresz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($alkatresz->id); ?>" ><?php echo e($alkatresz->edp); ?> - <?php echo e($alkatresz->megnevezes); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                  
                                </select>
                        </div>
                </div>       
                <div class="row justify-content-center my-3">
                        <button type="submit" class="btn btn-primary col-lg-2">Rögzités</button>                    
                </div>     

                <?php echo csrf_field(); ?>
            </form>  
            
      </div>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
      <script type="text/javascript">
             $(document).ready(function(){
                $('#printerSelect').select2();
                $('#partsSelect').select2();
             });
      </script>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/parts/usedCreate.blade.php ENDPATH**/ ?>