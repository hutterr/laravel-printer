<?php $__env->startSection('nav'); ?>
    <?php echo $__env->make('inc.navbar', ['title' => 'Nyomtatók listája', 'route' => 'cegek.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <?php if($errors->any()): ?>
    <div class="alert alert-success col-lg-11 my-3 mx-auto" role="alert">
    <?php echo e($errors->first('uzenet')); ?>

    </div>
  <?php endif; ?>
  <div class="row mx-auto mt-3" style="width: 80%">
    <form class="col-lg-2 form-inline" action="<?php echo e(route('nyomtatok.index')); ?>" method="get">
        <div class="form-group">
            <input class="form-control" name="gepszam" placeholder="Gépszám vagy típus">
          <div class="col-lg-2">
            <input class="btn btn-primary" type="submit" value="Keresés">
          </div>
        </div>
      </form>
  </div>
<table class="table table-hover mx-auto mt-3" >
        <thead>
          <tr>
            <th class="text-center" scope="col">Gépszam</th>
            <th class="text-center" scope="col">Márka</th>
            <th class="text-center" scope="col">Típus</th>
            <th class="text-center"scope="col">Hely</th>
            <th class="text-center" scope="col">Cég</th>
            <th class="text-center" scope="col"></th>
            
          
          </tr>
        </thead>
        <tbody>
          <?php if(count($nyomtatok) == 0): ?>
          <tr>
                  <th scope="row" colspan="7" class="text-center">Nincsenek még nyomtatók!</th>             
          </tr>
          <?php else: ?>
              <?php $__currentLoopData = $nyomtatok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nyomtato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
              <tr>             
                <td class="align-middle text-center"><a class="button-list" href="\nyomtatok\<?php echo e($nyomtato->id); ?>\edit"><?php echo e($nyomtato->gepszam); ?></a></td>
                <td class="align-middle text-center"><?php echo e($nyomtato->marka); ?></td>
                <td class="align-middle text-center"><?php echo e($nyomtato->geptipus); ?></td>
                <td class="align-middle text-center"><?php echo e($nyomtato->hely); ?></td>
                <td class="align-middle text-center"><?php echo e($nyomtato->ceg->cegnev); ?></td>  
                <td class="align-middle text-center"><a class="button-list" href="\nyomtatok\<?php echo e($nyomtato->id); ?>">Részletek</a></td>            
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table> 
      <?php if(count($nyomtatok) > 0): ?>
              <div class="paginate mx-auto mt-2" >
                  <?php echo e($nyomtatok->links()); ?>            
              </div>
      <?php endif; ?>
     
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\coding\laravel-printer\resources\views/printer/index.blade.php ENDPATH**/ ?>